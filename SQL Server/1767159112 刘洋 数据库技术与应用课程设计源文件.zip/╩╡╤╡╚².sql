USE BankDB
GO

-- 1. BankBusinessType表的测试数据
INSERT INTO BankBusinessType(BBTName, BBTCOMMENT) VALUES 
	('活期', '无固定存期，可随时存取，存取金额不限的一种比较灵活的存款') ,
	('定活两便', '事先不约定存期，一次性存入，一次性支取的存款') ,
	('通知', '不约定存期，支取时需提前通知银行，约定支取日和金额方能支取的存款') ,
	('整存整取1年', '正比存入，到期提取本息') ,
	('整存整取2年', '正比存入，到期提取本息') ,
	('整存整取3年', '正比存入，到期提取本息') ,
	('零存整取1年', '事先原定金额，逐月按约定金额存入，到期支付本息') ,
	('零存整取2年', '事先原定金额，逐月按约定金额存入，到期支付本息') ,
	('零存整取3年', '事先原定金额，逐月按约定金额存入，到期支付本息') ,
	('自助转账', '银行ATM存取款机上办理银行卡之间的相互划转')
GO
-- 测试用
SELECT * FROM BankBusinessType
GO

-- 2. BankDesposit表的测试数据
INSERT INTO BankDesposit VALUES
	('100001', '包头乐园支行', '包头市昆区包头乐园东门'),
	('100002', '包钢三中支行', '包头市昆区包头乐园南门'),
	('100003', '包钢五中支行', '包头市昆区包头乐园西门'),
	('100004', '内科大支行', '包头市昆区包头乐园北门'),
	('100005', '八一公园支行', '包头市昆区包头乐园东北门'),
	('100006', '友谊22号支行', '包头市昆区包头乐园西北门'),
	('100007', '包钢南桥支行', '包头市昆区包头乐园东南门'),
	('100008', '包百支行', '包头市昆区包头乐园西南门'),
	('100009', '少先路支行', '包头市昆区包头乐园西东门'),
	('100010', '银河广场支行', '包头市昆区包头乐园南北门'),
	('100011', '包头图书馆支行', '包头市昆区包头乐园北南门'),
	('100012', '青山一机支行', '包头市昆区包头乐园南南门'),
	('100013', '富强市场支行', '包头市昆区包头乐园北北门'),
	('100014', '大连新型支行', '包头市昆区包头乐园东东门'),
	('100015', '赛罕塔拉支行', '包头市昆区包头乐园西西门'),
	('100016', '劳动公园支行', '包头市昆区包头乐园东门50米')
GO
-- 测试用
SELECT * FROM BankDesposit
GO

-- 3. 批量添加客户的存储过程proc_InsertBankCustomer
CREATE PROC proc_InsertBankCustomer @Num INT
AS
BEGIN
	CREATE TABLE #TMP (
		BCName NCHAR(20) NOT NULL,								-- 客户名称
		BCICNo NCHAR(18) NOT NULL,								-- 客户身份证号
		BCTel NCHAR(20) NOT NULL,									-- 客户电话号
		BCAddr NCHAR(100) NULL										-- 客户地址
	)
	DECLARE @CNT INT = 0
	DECLARE @Name NVARCHAR(20), @ICNo NCHAR(18), @Tel NVARCHAR(20), @Add NVARCHAR(100)
	WHILE @CNT < @Num
	BEGIN
		-- 生成随机数据
		EXEC proc_randName @Name OUTPUT
		EXEC proc_randICNo @ICNo OUTPUT
		EXEC proc_randTel @Tel OUTPUT
		EXEC PROC_RandAdd @ADD OUTPUT
		INSERT INTO #TMP
				VALUES(@Name, @ICNo, @Tel, @Add)
		SELECT @CNT = @CNT + 1
	END
	INSERT INTO BankCustomer(BCName, BCICNo, BCTel, BCAddr) 
			SELECT * FROM #TMP
	DROP TABLE #TMP
END
GO
-- 测试用
EXEC proc_InsertBankCustomer 50000
SELECT * FROM BankCustomer
GO

-- 4. 批量添加银行卡的存储过程proc_InsertBankCard
CREATE PROC proc_InsertBankCard @Num INT
AS
BEGIN
	CREATE TABLE #TMP1 (
			BCNo NCHAR(19) NOT NULL UNIQUE,							-- 卡号（唯一）
			BCPwd NCHAR(6) NOT NULL DEFAULT '888888',			-- 密码
			BCCurrency NCHAR(5) NOT NULL DEFAULT 'RMB',		-- 币种
			BCBBTID INT NOT NULL,													-- 业务类型
			BCOpenDate DATE NOT NULL DEFAULT GETDATE(),		-- 开户日期
			BCOpenAmount MONEY NOT NULL,								-- 开户金额
			BCRegLoss NCHAR(2) NOT NULL DEFAULT '否',				-- 是否挂失
			BCBCID INT NOT NULL,													-- 客户编号
			BCExistBalance MONEY NOT NULL,								-- 账户余额
			BCBDID NCHAR(6) NULL,													-- 开户行编号
	)
	CREATE TABLE #TMP2 (
			BCNo NCHAR(19),								-- 卡号（唯一）
			BCPwd NCHAR(6),								-- 密码
			BCCurrency NCHAR(5),						-- 币种
			BCBBTID INT,										-- 业务类型
			BCOpenDate DATE,							-- 开户日期
			BCOpenAmount MONEY,					-- 开户金额
			BCRegLoss NCHAR(2),						-- 是否挂失
			BCBCID INT,										-- 客户编号
			BCExistBalance MONEY,					-- 账户余额
			BCBDID NCHAR(6)								-- 开户行编号
	)
	INSERT INTO #TMP1
		SELECT BCNo, BCPwd, BCCurrency, BCBBTID, BCOpenDate, BCOpenAmount, BCRegLoss, BCBCID, BCExistBalance, BCBDID FROM BankCard

	DECLARE @BCNo NCHAR(19), @BCPwd NCHAR(6), @BCCurrency NCHAR(5) = 'RMB', @BCBBTID INT, @BCOpenDate DATE, @BCOpenAmount MONEY, 
					@BCRegLoss NCHAR(2), @BCBCID INT, @BCExistBalance MONEY = 0, @BCBDID NCHAR(6)
	DECLARE @CNT INT = 0
	DECLARE @Total INT = (SELECT COUNT(*) FROM BankCustomer)
	WHILE @CNT < @Num
	BEGIN
		EXEC Proc_randCardID @BCNo OUTPUT
		EXEC Proc_randPwd @BCPwd OUTPUT
		EXEC PROC_RandBBTID @BCBBTID OUTPUT
		EXEC PROC_RandDate '1999-1-4', @BCOpenDate OUTPUT
		EXEC PROC_RandMoney 5000, @BCOpenAmount OUTPUT
		EXEC PROC_RandLoss @BCRegLoss OUTPUT
		EXEC PROC_RandBCID @Total, @BCBCID OUTPUT 
		EXEC PROC_RandBDID @BCBDID OUTPUT
		BEGIN TRY
			INSERT INTO #TMP1(BCNo, BCPwd, BCCurrency, BCBBTID, BCOpenDate, BCOpenAmount, BCRegLoss, BCBCID, BCExistBalance, BCBDID)
					VALUES(@BCNo, @BCPwd, @BCCurrency, @BCBBTID, @BCOpenDate, @BCOpenAmount, @BCRegLoss, @BCBCID, @BCExistBalance, @BCBDID)
			INSERT INTO #TMP2(BCNo, BCPwd, BCCurrency, BCBBTID, BCOpenDate, BCOpenAmount, BCRegLoss, BCBCID, BCExistBalance, BCBDID)
					VALUES(@BCNo, @BCPwd, @BCCurrency, @BCBBTID, @BCOpenDate, @BCOpenAmount, @BCRegLoss, @BCBCID, @BCExistBalance, @BCBDID)
		END TRY
		BEGIN CATCH
			SELECT '生成BackCard数据出错，重新生成'
			SELECT @CNT = @CNT - 1
		END CATCH
		SELECT @CNT = @CNT + 1
	END
	INSERT INTO BankCard (BCNo, BCPwd, BCCurrency, BCBBTID, BCOpenDate, BCOpenAmount, BCRegLoss, BCBCID, BCExistBalance, BCBDID)
		SELECT * FROM #TMP2
	DROP TABLE #TMP1
	DROP TABLE #TMP2
END
GO
-- 测试用
EXEC proc_InsertBankCard 100000
SELECT * FROM BankCard
GO

-- 5. 批量添加交易记录的存储过程proc_InsertBankDealInfo
ALTER PROC proc_InsertBankDealInfo @Num INT
AS
BEGIN
	CREATE TABLE #TMP1 (
			BDBCNo NCHAR(19),										-- 银行卡号
			BDDealDate DATE,											-- 交易日期
			BDDealAcount MONEY,									-- 交易金额
			BDDealType NCHAR(10),								-- 交易类型
			BDDealComment NVARCHAR(100) 			-- 描述
	)
	SELECT BCNo, BCOpenDate, BCID INTO #TMP2 FROM BankCard
	CREATE INDEX IDX_TMP2_BCID ON #TMP2(BCID)
	CREATE INDEX IDX_TMP2_BCNo ON #TMP2(BCNo)
	DECLARE @Total INT = (SELECT COUNT(BCNo) FROM BankCard)
	DECLARE @BDBCNo NCHAR(19), @BDDealDate DATE = GETDATE(), @BDDealAcount MONEY, @BDDealType NCHAR(10), @BDDealComment NVARCHAR(100) = '这是一条自动生成的数据'
	DECLARE @CurCardNo NCHAR(19) = NULL, @CurCardDate DATE
	DECLARE @RandNum INT
	WHILE @Num > 0
	BEGIN
		WHILE @CurCardNo IS NULL
		BEGIN
			SELECT @CurCardNo = ( SELECT BCNo FROM #TMP2 WHERE CAST(RAND() * @TOTAL + 1 AS INT) = BCID )
			IF @CurCardNo IS NOT NULL
				SELECT @CurCardDate = ( SELECT BCOpenDate FROM #TMP2 WHERE @CurCardNo = BCNo )
		END
		DECLARE @CNT INT = 0
		SELECT @BDBCNo = @CurCardNo
		WHILE @CNT < 5 AND @Num > 0
		BEGIN
			EXEC PROC_RandDate @CurCardDate, @BDDealDate OUTPUT
			EXEC PROC_RandMoney 0, @BDDealAcount OUTPUT
			EXEC PROC_RandDealType @BDDealType OUTPUT
			INSERT INTO #TMP1 VALUES(@BDBCNo, @BDDealDate, @BDDealAcount, @BDDealType, @BDDealComment)
			SELECT @CNT = @CNT + 1
			SELECT @Num = @Num - 1
		END
		SELECT @CurCardNo = NULL
	END
	INSERT INTO BankDealInfo(BDBCNo, BDDealDate, BDDealAcount, BDDealType, BDDealComment)
		SELECT * FROM #TMP1
	DROP TABLE #TMP1
	DROP TABLE #TMP2
END
GO
-- 测试用
set statistics time OFF
proc_InsertBankDealInfo 5000000
SELECT * FROM BankDealInfo
SELECT * FROM BankCard
GO

dbcc checkident('BankDealInfo',reseed,0);

DELETE FROM BankDealInfo

SELECT COUNT(*) FROM BankDealInfo

DELETE top(1) FROM BankDealInfo