-- 建库
CREATE DATABASE BankDB;
GO

USE BankDB;
GO

-- 银行业务类型表
CREATE TABLE BankBusinessType (
	BBTID INT IDENTITY(1, 1) PRIMARY KEY,					-- 银行业务类型编号
	BBTName NCHAR(20) NOT NULL,								-- 银行业务类型名称
	BBTComment NVARCHAR(100) NULL							-- 银行业务描述
);

-- 开户网点信息
CREATE TABLE BankDesposit (
	BDID NCHAR(6) PRIMARY KEY,								-- 网点编号
	BDName NCHAR(20) NOT NULL,							-- 网点名称
	BDAddress NCHAR(50) NULL								-- 网点地址
);

-- 客户信息
CREATE TABLE  BankCustomer (
	BCID INT IDENTITY(1, 1) PRIMARY KEY,					-- 客户编号
	BCName NCHAR(20) NOT NULL,								-- 客户名称
	BCICNo NCHAR(18) NOT NULL,								-- 客户身份证号
	BCTel NCHAR(20) NOT NULL,									-- 客户电话号
	BCAddr NCHAR(100) NULL										-- 客户地址
);

-- 银行卡
CREATE TABLE BankCard (
	BCNo NCHAR(19) NOT NULL UNIQUE,							-- 卡号（唯一）
	BCPwd NCHAR(6) NOT NULL DEFAULT '888888',			-- 密码
	BCCurrency NCHAR(5) NOT NULL DEFAULT 'RMB',		-- 币种
	BCBBTID INT NOT NULL,													-- 业务类型
	BCOpenDate DATE NOT NULL DEFAULT GETDATE(),		-- 开户日期
	BCOpenAmount MONEY NOT NULL,								-- 开户金额
	BCRegLoss NCHAR(2) NOT NULL DEFAULT '否',				-- 是否挂失
	BCBCID INT NOT NULL,													-- 客户编号
	BCExistBalance MONEY NOT NULL,								-- 账户余额
	BCBDID NCHAR(6) NULL,													-- 开户行编号
	BCID INT IDENTITY(1, 1) PRIMARY KEY							-- 卡编号
);

-- 交易信息
CREATE TABLE BankDealInfo (
	BDNo INT IDENTITY(1, 1) PRIMARY KEY,						-- 交易编号
	BDBCNo NCHAR(19) NOT NULL,										-- 银行卡号
	BDDealDate DATE NOT NULL,											-- 交易日期
	BDDealAcount MONEY NOT NULL,								-- 交易金额
	BDDealType NCHAR(10) NOT NULL,								-- 交易类型
	BDDealComment NVARCHAR(100) NULL					-- 描述
);
GO

-- 添加约束
ALTER TABLE BankCard
	ADD CONSTRAINT FK_BC_BBT FOREIGN KEY(BCBBTID) REFERENCES BankBusinessType(BBTID)	-- BC 和 BBT 外键

ALTER TABLE BankCard
	ADD CONSTRAINT FK_BC_BD FOREIGN KEY(BCBDID) REFERENCES BankDesposit(BDID)					-- BC 和 BD 外键

ALTER TABLE BankDealInfo
	ADD CONSTRAINT FK_BD_BC FOREIGN KEY(BDBCNo) REFERENCES BankCard(BCNo)						-- BDI 和 BC 外键

-- 优化
CREATE INDEX ID_BDAddress ON BankDesposit(BDAddress)
CREATE INDEX ID_BDBCNo ON BankDealInfo(BDBCNo)
CREATE INDEX ID_BCBCId ON BankCard(BCBCId)
CREATE INDEX ID_BCBBTID ON BankCard(BCBBTID)
CREATE INDEX ID_BCBDID ON BankCard(BCBDID)
CREATE INDEX ID_BDDealType ON BankDealInfo(BDDealType)

use master
declare @dbname varchar ( 20)
set @dbname = 'BankDB'
declare @sql nvarchar ( 500)
declare @spid int --SPID 值是当用户进行连接时指派给该连接的一个唯一的整数
set @sql = 'declare getspid cursor for select spid from sysprocesses where dbid=db_id(''' + @dbname + ''')'
exec ( @sql )
open getspid
fetch next from getspid into @spid
while @@fetch_status <>- 1-- 如果 FETCH 语句没有执行失败或此行不在结果集中。
begin
exec ( 'kill ' + @spid ) -- 终止正常连接
fetch next from getspid into @spid
end
close getspid
deallocate getspid