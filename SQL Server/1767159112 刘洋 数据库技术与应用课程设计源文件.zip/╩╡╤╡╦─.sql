-- 1. 使用T-SQL向已经创建的BankBusinessType表插入如下10条数据
-- 实训3 已插入

-- 2. 使用T-SQL语句插入16条开户网点信息，具体数据如下所示：
-- 实训3 已插入

-- 3. 数据批量添加
-- 展示插入结果
SELECT COUNT(*) FROM BankCard
SELECT COUNT(*) FROM BankCustomer
SELECT COUNT(*) FROM BankDealInfo