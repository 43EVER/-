USE BankDB
GO

--- 1. 更新BankCard的余额信息
SELECT * INTO #TMP1 FROM BankDealInfo
SELECT * INTO #TMP2 FROM BankCard
UPDATE #TMP2 set BCExistBalance = 
	BCOpenAmount 
	+ (SELECT ISNULL(SUM(BDDealAcount),0) FROM #TMP1 WHERE BDBCNo=BCNo and RTRIM(LTRIM(BDDealType)) in('转入','存款'))
	- (SELECT ISNULL(SUM(BDDealAcount),0) FROM #TMP1 WHERE BDBCNo=BCNo and RTRIM(LTRIM(BDDealType)) in('转出','取款'))
 WHERE BCNo in(SELECT DISTINCT BDBCNo FROM #TMP1);
UPDATE BankCard set BCExistBalance = (SELECT BCExistBalance FROM #TMP2 WHERE #TMP2.BCID = BankCard.BCID)
DROP TABLE #TMP1
DROP TABLE #TMP2
GO
-- 测试用
SELECT * FROM BankCard
GO

 -- 2. 修改存款类型为活期的银行卡密码
 UPDATE BankCard set BCPwd = SUBSTRING( 
										(SELECT BCICNo FROM BankCustomer WHERE BankCard.BCID = BankCustomer.BCID), 
										9, 
										6)
		WHERE EXISTS (SELECT  * FROM BankBusinessType
										WHERE BBTName = '活期' AND BankCard.BCBBTID = BankBusinessType.BBTID)
						AND EXISTS (SELECT BCICNo FROM BankCustomer WHERE BankCard.BCID = BankCustomer.BCID);
GO
-- 测试用
SELECT * FROM BankCard
GO

-- 3. 创建一个视图vw_SelectExistBalanceLower0
CREATE VIEW vw_SelectExistBalanceLower0
AS
SELECT BCNo 卡号, BCPwd 密码, BCCurrency 货币类型, BBTName 储蓄类型, BCOpenDate 开户日期, 
								BCOpenAmount 开户金额, BCRegLoss 是否挂失, BCName 客户姓名, BCExistBalance 存款余额, BDName 开户点名称
	FROM BankCard INNER JOIN BankCustomer ON BankCard.BCBCID = BankCustomer.BCID 
				INNER JOIN BankBusinessType ON BankBusinessType.BBTID = BankCard.BCBBTID
				INNER JOIN BankDesposit ON BankDesposit.BDID = BankCard.BCBDID
	WHERE BCExistBalance < 0
GO
-- 测试用
SELECT * FROM vw_SelectExistBalanceLower0
GO

-- 4. 创建存储过程proc_staticsBanlanceAndProfit
ALTER PROC proc_staticsBanlanceAndProfit @BCName NCHAR(20)
AS
BEGIN
	DECLARE @DepositedAmount  MONEY, @WithdrawAmount MONEY, @Profit MONEY, @BalanceOfCapitalCirculation MONEY;
	SELECT @DepositedAmount = SUM(BDDealAcount) 
		FROM BankDealInfo INNER JOIN BankCard ON BankCard.BCNo = BankDealInfo.BDBCNo
										INNER JOIN BankCustomer ON BankCustomer.BCID = BankCard.BCBCID
		WHERE BDDealType IN ('转入', '存款') AND BCName = @BCName AND BCRegLoss = '否'
		GROUP BY BankCustomer.BCID

	SELECT @WithdrawAmount = SUM(BDDealAcount) 
		FROM BankDealInfo INNER JOIN BankCard ON BankCard.BCNo = BankDealInfo.BDBCNo
				INNER JOIN BankCustomer ON BankCustomer.BCID = BankCard.BCBCID
		WHERE BDDealType IN ('转出', '取款') AND BCName = @BCName AND BCRegLoss = '否'
		GROUP BY BankCustomer.BCID

	SELECT @BalanceOfCapitalCirculation = @DepositedAmount - @WithdrawAmount
	SELECT @Profit = ( @DepositedAmount * 0.008 ) - ( @WithdrawAmount * 0.003 )

	PRINT '客户名称为' + RTRIM(@BCName) + ',存入总金额:' + 
			CONVERT(NVARCHAR, @DepositedAmount) + '元，银行流通余额:' + CONVERT(NVARCHAR, @WithdrawAmount) + '元'
	PRINT '盈利余额:' + CONVERT(NVARCHAR, @Profit) + '元'
END
GO
-- 测试用
proc_staticsBanlanceAndProfit '赛雨寒'
GO

-- 5. 输出银行客户记录视图vw_selectCustomer
DROP VIEW IF EXISTS vw_selectCustomer;
GO
CREATE VIEW dbo.vw_selectCustomer
AS
	SELECT BCID 客户编号,  BCName 开户名, BCICNo 身份证号, BCTel 电话号码, BCAddr 居住地址 FROM BankCustomer
GO
-- 测试用
SELECT TOP(10) * FROM vw_selectCustomer
GO

-- 6. 输出银行卡记录视图vw_SelectBankCard
CREATE VIEW vw_SelectBankCard
AS
	SELECT BCNo 卡号, BCName 开户名, BCCurrency 货币种类, BBTName 存款类型, BCOpenDate 开户日期, BCOpenAmount 开户金额, BCExistBalance 存款余额, 
			BCPwd 密码, BCRegLoss 是否挂失, BCAddr 开户网点
	FROM BankCard INNER JOIN BankCustomer ON BankCard.BCBCId = BankCustomer.BCID
											INNER JOIN BankBusinessType ON BankCard.BCBBTID = BankBusinessType.BBTID
GO
-- 测试用
SELECT TOP(10) * FROM vw_SelectBankCard ORDER BY (卡号)
GO

-- 7. 输出银行卡交易记录视图VW_TransInfo
CREATE VIEW VW_TransInfo
AS
	SELECT BDDealDate 交易日期, BDDealType 交易类型, BDBCNo 卡号, BDDealAcount 交易金额, BDDealComment 备注 
		FROM BankCard INNER JOIN BankDealInfo ON BankCard.BCNo = BankDealInfo.BDBCNo
GO
-- 测试用
SELECT TOP(10) * FROM VW_TransInfo
GO

-- 8. 创建存储过程查询没有交易记录
ALTER PROC proc_searchCustomerNoDeal @BeginDate Date, @EndDate Date
AS
BEGIN
	DECLARE @Now DATE
	SELECT @Now = GETDATE()
	SELECT * FROM BankDealInfo WHERE DATEDIFF(DAY, @BeginDate, BDDealDate) >= 0 AND DATEDIFF(DAY, BDDealDate, @EndDate) >= 0
END
GO
-- 测试用
proc_searchCustomerNoDeal '2018-7-1', '2019-1-1'
GO

-- 9. 催款提醒业务存储过程proc_Reminders
CREATE PROC proc_Reminders
AS
BEGIN
	SELECT BCBCID 编号, BCNo 卡号, BCName 客户姓名, BCTel 客户电话, BCExistBalance 卡上余额, BCAddr 开户网点 
				FROM BankCard INNER JOIN BankCustomer ON BankCard.BCBCID = BankCustomer.BCID
											INNER JOIN BankDesposit ON BankDesposit.BDID = BankCard.BCBDID
				WHERE BCExistBalance < 0
				ORDER BY(BCAddr)
END
GO
-- 测试用
proc_Reminders
GO